export default function SolutionsPage(){
  return (
    <section id="solutions" className="py-12">
      <div className="container">
        <h2 className="text-3xl font-semibold mb-4">Our Solutions</h2>
        <p className="mb-6">Products proudly developed by Trendify Group Ltd.</p>
      </div>
    </section>
  )
}
